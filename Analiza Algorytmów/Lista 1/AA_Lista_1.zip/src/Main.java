import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;




import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Main {

	public static Random rand = new Random();
	
	public static int election_1(int n) {
		String status = "NULL";
		int slotsCounter = 1;
		while (!status.equals("SINGLE")) {
			status = "NULL";
			for (int i = 0; i < n; i++) {
				double broadcast = rand.nextDouble();
				if (broadcast < ((double) 1 / n)) {
					if (status.equals("NULL"))
						status = "SINGLE";
					else if (status.equals("SINGLE")) {
						status = "CONFLICT";
					}
				}
			}
			slotsCounter++;
		}
		return (slotsCounter - 1);
	}
	
	public static int election_2(int u, int n) {
		String status = "NULL";
		double l = Math.ceil(Math.log(u) / Math.log(2));
		int roundCounter = 1;
		while (!status.equals("SINGLE")) {
			for (int i = 1; i <= l; i++) {
				status = "NULL";
				for (int j = 0; j < n; j++) {
					double broadcast = rand.nextDouble();
					if (broadcast < ((double) 1 / Math.pow(2.0, i))) {
						if (status.equals("NULL"))
							status = "SINGLE";
						else if (status.equals("SINGLE")) {
							status = "CONFLICT";
						}
					}
				}
			}
			roundCounter++;
		}
		return (roundCounter - 1);
	}
	
	public static void generateHistogram_1(int n, int numberOfExperiments) {
		Map<Integer, Integer> slots = new HashMap<Integer, Integer>();
		
		for (int i = 0; i < numberOfExperiments; i++) {
			int slot = election_1(n);
			if (slots.containsKey(slot)) {
				slots.put(slot, slots.get(slot) + 1);
			} else {
				slots.put(slot, 1);
			}
		}
		
		Histogram demo = new Histogram("Histogram - Known n", slots);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
	}
	
	public static void generateHistogram_2(int u) {
		Map<Integer, Integer> rounds = new HashMap<Integer, Integer>();
		int round1, round2, round3;
		for (int i = 2; i <= u; i++) {
			round1 = round2 = round3 = 0;
			round1 = election_2(i, 2);
			if (i/2 > 2) round2 = election_2(i, i/2);
			if (i > 2) round3 = election_2(i, i);
				
			if (rounds.containsKey(round1)) rounds.put(round1, rounds.get(round1) + 1);
			else rounds.put(round1, 1);
			if (round2 != 0) {
				if (rounds.containsKey(round2)) rounds.put(round2, rounds.get(round2) + 1);
				else rounds.put(round2, 1);
			}
			if (round3 != 0) {
				if (rounds.containsKey(round3)) rounds.put(round3, rounds.get(round3) + 1);
				else rounds.put(round3, 1);
			}
		}
		
		Histogram demo = new Histogram("Histogram - Known only u", rounds);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
	}
	
	// This version for every n from 2 to u runs number of tests = numberOfExperiments
	public static void generateHistogram_2(int u, int numberOfExperiments) {
		Map<Integer, Integer> rounds = new HashMap<Integer, Integer>();
		int round1, round2, round3;
		// For every n from 2 to u calculate three values (if applicable)
		for (int i = 2; i <= u; i++) {
			for (int j = 0; j < numberOfExperiments; j++) {
				round1 = round2 = round3 = 0;
				round1 = election_2(i, 2);
				if (i/2 > 2) round2 = election_2(i, i/2);
				if (i > 2) round3 = election_2(i, i);
					
				if (rounds.containsKey(round1)) rounds.put(round1, rounds.get(round1) + 1);
				else rounds.put(round1, 1);
				if (round2 != 0) {
					if (rounds.containsKey(round2)) rounds.put(round2, rounds.get(round2) + 1);
					else rounds.put(round2, 1);
				}
				if (round3 != 0) {
					if (rounds.containsKey(round3)) rounds.put(round3, rounds.get(round3) + 1);
					else rounds.put(round3, 1);
				}
			}
		}
		
		Histogram demo = new Histogram("Histogram - Known only u", rounds);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
	}
	
	public static void lemma(int u) {
		int firstRoundsSuccess = 0;
		int totalNumberOfExperiments = 0;
		for (int i = 2; i <= u; i++) {
			for (int j = 2; j <= i; j++) {
				int numberOfRounds = election_2(i, j);
				if (numberOfRounds == 1) {
					firstRoundsSuccess++;
				}
				totalNumberOfExperiments++;
			}
		}
		System.out.println((double) firstRoundsSuccess / totalNumberOfExperiments);
	}	

	public static void main(String[] args) {
		//System.out.println(election_1(1000));
		System.out.println(election_2(100, 90));
		
		//generateHistogram_1(300, 1000);
		//generateHistogram_2(100);
		//generateHistogram_2(100, 10);
		
		//lemma(350);
	}

	public static class Histogram extends ApplicationFrame {
		
		private double[][] data;
		private Map<Integer, Integer> dataMap;

		public Histogram(String title, double[][] data) {
	        super(title);
	        this.data = data;
	        IntervalXYDataset dataset = createDatasetTable();
	        JFreeChart chart = createChart(dataset);
	        final ChartPanel chartPanel = new ChartPanel(chart);
	        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
	        setContentPane(chartPanel);
	    }
		
		public Histogram(String title, Map<Integer, Integer> dataMap) {
	        super(title);
	        this.dataMap = dataMap;
	        IntervalXYDataset dataset = createDatasetMap();
	        JFreeChart chart = createChart(dataset);
	        final ChartPanel chartPanel = new ChartPanel(chart);
	        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
	        setContentPane(chartPanel);
	    }
	    
	    private IntervalXYDataset createDatasetTable() {
	        final XYSeries series = new XYSeries("L");
	        for (double[] pair: data) {
	        	series.add(pair[0], pair[1]);
	        }
	        final XYSeriesCollection dataset = new XYSeriesCollection(series);
	        return dataset;
	    }
	    
	    private IntervalXYDataset createDatasetMap() {
	        final XYSeries series = new XYSeries("L");
	        for (Map.Entry<Integer, Integer> entry: dataMap.entrySet()) {
	        	series.add(entry.getKey(), entry.getValue());
	        }
	        final XYSeriesCollection dataset = new XYSeriesCollection(series);
	        return dataset;
	    }

	    private JFreeChart createChart(IntervalXYDataset dataset) {
	        final JFreeChart chart = ChartFactory.createXYBarChart(
	            "Histogram",
	            "Number of rounds", 
	            false,
	            "Amount", 
	            dataset,
	            PlotOrientation.VERTICAL,
	            true,
	            true,
	            false
	        );
	        return chart;    
	    }
	}	
}