import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.util.Arrays;
import java.util.Random;

public final class Main {

    private static UndirectedGraph<Integer, DefaultEdge> createStringGraph() {
        UndirectedGraph<Integer, DefaultEdge> g = new SimpleGraph<>(DefaultEdge.class);

        for (int i = 0; i < 5; i++) {
            g.addVertex(i);
        }

        // add edges to create a circuit
        g.addEdge(0, 1);
        g.addEdge(1, 2);
        g.addEdge(1, 3);
        g.addEdge(2, 3);
        g.addEdge(3, 4);

        return g;
    }


    public static void main(String [] args) {
        int n = Integer.parseInt(args[0]);
        UndirectedGraph<Integer, DefaultEdge> integerGraph = createStringGraph();

        // note undirected edges are printed as: {<v1>,<v2>}
        System.out.println(integerGraph.toString());

        Random randomGenerator = new Random();
        boolean[] dep = new boolean[n];
        for (int i = 0; i < n; i++) {
            dep[i] = randomGenerator.nextBoolean();
        }

        System.out.println(Arrays.toString(dep));

        for (int t = 0; t < 10; t++) {
            for (int i = 0; i < n; i++) {
                new MISThread(integerGraph, dep, i).run();
            }
        }

        System.out.println(Arrays.toString(dep));
    }
}
