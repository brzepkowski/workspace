//Obliczenia naukowe - Lista 1
//Bartosz Rzepkowski - 18.10.2015 r.


#include<stdio.h>
#include<float.h>

int main() {
	printf("Epsilon for float16 = %.20e\n", FLT_EPSILON);
	printf("Epsilon for float16 = %.20e\n", DBL_EPSILON);
	printf("Epsilon for float16 = %.20Le\n", LDBL_EPSILON);
}
