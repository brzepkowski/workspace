 import java.util.Iterator;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Producer implements Runnable{
        
    private final BlockingQueue machines, queueBP, addQueue, minQueue, multiQueue;
    private final BlockingQueue addMachines, multiMachines, brokenM;
    Data data;
    Rekord record;
    AddingMachine add;
    MultiplyingMachine multi;
    int num1,num2,result;
    char check;
    int id, number, manId;
    boolean broken;
    
    public Producer (BlockingQueue queueBP, BlockingQueue addQueue, BlockingQueue minQueue, BlockingQueue multiQueue, BlockingQueue machine, BlockingQueue brokenM, BlockingQueue addMachines, BlockingQueue multiMachines, int id, int manId) {
        this.queueBP = queueBP;
        this.addQueue=addQueue;
        this.minQueue=minQueue;
        this.multiQueue=multiQueue;
        this.machines=machine;
        this.addMachines=addMachines;
        this.multiMachines=multiMachines;
        this.brokenM=brokenM;
        data=new Data();
        this.id=id;
        this.manId=manId;
    }
      

    @Override
    public void run() {
        
        
        while(true){
            
            if(machines.isEmpty()){
                try {
                    
                    if(queueBP.isEmpty() && data.isUser()==false) {
                        //System.out.println("Worker " + Integer.toString(manId) + "." +Integer.toString(id) + " : Nothing to take ");
                    }
                    
                    if(data.numberOfClients()==0){ // && magazine.size()==data.magazineQueue()){
                        if(data.isUser()==false)
                            System.out.println("No clients, nothing else will be produced");
                        System.exit(0);
                    }   
                    
                    record= (Rekord) queueBP.take();
                    check=record.getMark();
                    num1=record.getNum1();
                    num2=record.getNum2();
                
                    switch(check){
                        case '+':{
                            takeAdd();
                            
                            if(data.isUser()==false)
                                System.out.println("Worker " + Integer.toString(manId) + "." + Integer.toString(id) + " : Task "+ Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result+", now to the magazine");
                        
                            while(data.addQueue()==addQueue.size()){
                                //if(data.isUser()==false)
                                //    System.out.println(Integer.toString(id) + " To many things in magazine. I'm waiting");
                                int takeSleep=data.makeSleepTime();
                                Thread.sleep(takeSleep);
                            }
                            
                            addQueue.put(new Rekord (num1, num2, check, result));
                            
                            break;}
                        case '-':{
                            result=num1-num2;
                            
                            if(data.isUser()==false)
                                System.out.println("Worker " + Integer.toString(manId) +"."+ Integer.toString(id) + " : Task "+ Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result+", now to the magazine");
                            
                            while(data.minQueue()==addQueue.size()){
                                //if(data.isUser()==false)
                                //    System.out.println(Integer.toString(id) + " To many things in magazine. I'm waiting");
                                int takeSleep=data.makeSleepTime();
                                Thread.sleep(takeSleep);
                            }
                            
                            minQueue.put(new Rekord (num1, num2, check, result));
                            
                            break;}
                        case '*':{
                            if(!(data.numberOfProducers()==1))
                                takeMulti();
                            else{
                                if(data.isUser()==false)
                                    System.out.println("Worker " + Integer.toString(manId) + "." + Integer.toString(id) + " : Task "+ Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result+", deleted. Cause: only one worker at work");
                            } 
                            break;
                            }
                        default:{
                            result=Integer.MAX_VALUE;
                        break;
                        }
                    }
                    
                    check=record.getMark();
                    num1=record.getNum1();
                    num2=record.getNum2();
                    
                    int getSleep=data.makeSleepTime();
                    Thread.sleep(getSleep);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
            else{
                try {
                    multi=(MultiplyingMachine) machines.take();
                    record= multi.passTask();

                    check=record.getMark();
                    num1=record.getNum1();
                    num2=record.getNum2();
                    result=record.getFinalResult();

                    if(data.isUser()==false)
                        System.out.println("Worker " + Integer.toString(manId) + "." + Integer.toString(id) + " : Task "+ Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result+", now to the magazine");

                    multi.PushSecondButton(true);
                    
                    while(data.addQueue()==multiQueue.size()){
                        //if(data.isUser()==false)
                         //   System.out.println(Integer.toString(id) + " To many things in magazine. I'm waiting");
                        int takeSleep=data.makeSleepTime();
                        Thread.sleep(takeSleep);
                    }
                    
                    multiQueue.put(new Rekord (num1, num2, check, result));
                     
                    multiMachines.put(multi);
                    int takeSleep=data.makeSleepTime();
                    Thread.sleep(takeSleep);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                    
        } 
    }
    
    public boolean defineIfBroken(){
        int checkB=4;
        int blabla=isBroken();
        if(checkB==blabla){
            broken=true;
        }
        else{
            broken=false;}
        return broken;
    }
    
    public int isBroken(){
        Random rand=new Random();
        int min=data.brokenMin();
        int max=data.brokenMax();
        number=rand.nextInt(max-min+1);
        return number;
    }
    
    public void takeAdd() throws InterruptedException{
        while(addMachines.isEmpty()){
            int takeSleep=data.makeSleepTime();
            Thread.sleep(takeSleep);
            //System.out.println("Worker " + Integer.toString(manId) + "." + Integer.toString(id) + " : I'm waiting for adding machine ");
        }
        add=(AddingMachine) addMachines.take();
        if(defineIfBroken()==false){
            record=add.getData(record);
            result=record.getFinalResult();
            addMachines.put(add);
            
        }
        else{
            System.out.println("Adding " + Integer.toString(manId) + "." + Integer.toString(add.returnID()) + " down");
            brokenM.put(add);
            takeAdd();
        }
    }
    
    public void takeMulti() throws InterruptedException{
        while(multiMachines.isEmpty()){
            int takeSleep=data.makeSleepTime();
            Thread.sleep(takeSleep);
            //System.out.println("Worker " + Integer.toString(manId) + "." + Integer.toString(id) + " : I'm waiting for multiplying machine ");
        }
            multi=(MultiplyingMachine) multiMachines.take();
            if(defineIfBroken()==false){
                multi.giveRecord(record);
                machines.put(multi);
                while(multi.returnSecond()==false){
                    int takeSleepfe=data.makeSleepTime();
                    Thread.sleep(takeSleepfe);
                }
            }
            else{
                System.out.println("Multipying " + Integer.toString(manId) + "." + Integer.toString(multi.returnID()) + " down");
                brokenM.put(multi);
                takeMulti();
            }
    }
}