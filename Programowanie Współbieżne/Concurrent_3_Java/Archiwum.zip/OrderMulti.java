
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Asia
 */
public class OrderMulti implements Runnable{
    
    Data data; 
    LorryInc lorry;
    private final BlockingQueue multiTask;
    private final BlockingQueue lorriesAv;
    int shopId;
    
    public OrderMulti(BlockingQueue<LorryInc> multiTask, BlockingQueue lorriesAv, int shopId) {
        data=new Data();
        this.multiTask=multiTask;
        this.lorriesAv=lorriesAv;
        this.shopId=shopId;
    }

   @Override
    public void run() {
        
        while(true){  
            if(multiTask.size()<=1){
                callLorry("multiplying", 3);
            }
        }
    }
    
    public void callLorry(String action, int num){
        
        try {
            while(lorriesAv.isEmpty()){
                int takeSleepfe=data.makeSleepTime();
                    Thread.sleep(takeSleepfe);
            }
            
            lorry = (LorryInc) lorriesAv.take();
            System.out.println("Shop "+ Integer.toString(shopId)+ " : is ordering " + action);
            lorry.getType(num, shopId);
            
            while(lorry.returnFreedom()==false){
                    int takeSleepfe=data.makeSleepTime();
                    Thread.sleep(takeSleepfe);
                }
            lorriesAv.put(lorry);
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    
}
