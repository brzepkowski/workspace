/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Asia
 */
public class Rekord {
    public int num1;
    public int num2;
    public int finalResult;
    public char mark;
    
    public Rekord(int l1, int l2, char znak, int result) {
        this.num1 = l1;
        this.num2 = l2;
        this.mark=znak;
        this.finalResult=result;
    }

    public int getNum1() {
        return num1;
    }

    public int getNum2() {
        return num2;
    }

    public int getFinalResult() {
        return finalResult;
    }

    public char getMark() {
        return mark;
    }
    
    
}
