import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Asia
 */

//CHECK menu, coś z listami i kolejkami


public class LorryInc {

    static Data data;
    static Rekord record;
    static GraphPro graph;
    static ManufacturePattern man;
    static ShopPattern sh;
    int id, manId = 0, shopId;
    int manIndex = 0, shopIndex = 0;
    CopyOnWriteArrayList manList;
    CopyOnWriteArrayList shopList;
    String[] kind;
    int ArrayNum;
    boolean free = false;
    Rekord[] transport;

    public LorryInc(CopyOnWriteArrayList manList, CopyOnWriteArrayList shopList, int id) {
        data = new Data();
        graph = new GraphPro();
        this.manList = manList;
        this.shopList = shopList;
        this.id = id;
        ArrayNum = data.numberOfManufactures() + data.numberOfShops() + 1;
        kind = new String[ArrayNum];
        transport = new Rekord[data.numberOfLorries()];
    }

    public void getType(int type, int shopIdGiven) throws InterruptedException {

        System.out.println("Lorry " + Integer.toString(id) + " : called by shop " + Integer.toString(shopIdGiven));

        int path;
        shopId = shopIdGiven;

        for (int x = 0; x < ArrayNum; x++) {
            kind[x] = graph.kindArrayElem(x);
        }

        shopIndex = 0;

        while (!(kind[shopIndex].equals("shop" + Integer.toString(shopId)))) {
            shopIndex++;
        }

        arrivalTime(shopIndex, 0);

        checkIfAnything(type);

        System.out.println("Lorry " + Integer.toString(id) + " : arrived to Shop " + Integer.toString(shopId));

        arrivalTime(shopIndex, 0);

    }

    public void arrivalTime(int shopIndex, int manIndex) {

        int path;

        if (manIndex == 0) {
            path = graph.returnWeight(1, shopIndex);
        } else if (shopIndex == 0) {
            path = graph.returnWeight(1, manIndex);
        } else {
            path = graph.returnWeight(1, shopIndex) + graph.returnWeight(1, manIndex);
        }

        int returnToBase = data.sleepLorry() * path;

        try {
            Thread.sleep(returnToBase);
        } catch (InterruptedException ex) {
            Logger.getLogger(MultiplyingMachine.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void checkIfAnything(int type) throws InterruptedException {

        if (type == 1) {
            checkManufacture(type);

            while (!(kind[manIndex].equals("manufacture" + Integer.toString(manId)))) {
                manIndex++;
            }

            arrivalTime(shopIndex, manIndex);

            while (!(man.addQReturn().size() >= 1)) {
                int returnToBase = data.sleepLorry();
                Thread.sleep(returnToBase);
            }
            transport[id] = (Rekord) man.addQReturn().take();
            record = transport[id];
        }

        if (type == 2) {
            checkManufacture(type);
            while (!(kind[manIndex].equals("manufacture" + Integer.toString(manId)))) {
                manIndex++;
            }

            arrivalTime(shopIndex, manIndex);

            while (!(man.minQReturn().size() >= 1)) {
                int returnToBase = data.sleepLorry();
                Thread.sleep(returnToBase);
            }
            transport[id] = (Rekord) man.minQReturn().take();
            record = transport[id];

        }
        if (type == 3) {
            checkManufacture(type);
            while (!(kind[manIndex].equals("manufacture" + Integer.toString(manId)))) {
                manIndex++;
            }

            arrivalTime(shopIndex, manIndex);

            while (!(man.multiQReturn().size() >= 1)) {
                int returnToBase = data.sleepLorry();
                Thread.sleep(returnToBase);
            }
            transport[id] = (Rekord) man.multiQReturn().take();
            record = transport[id];
        }


        System.out.println("Lorry " + Integer.toString(id) + " took : " + Integer.toString(record.getNum1()) + Character.toString(record.getMark()) + Integer.toString(record.getNum2()) + " = " + Integer.toString(record.getFinalResult()));

        arrivalTime(shopIndex, manIndex);
        checkShop();

        if (type == 1) {
            sh.addQReturn().put(transport[id]);
        }
        if (type == 2) {
            sh.minQReturn().put(transport[id]);
        }
        if (type == 3) {
            sh.multiQReturn().put(transport[id]);
        }

        record = transport[id];
        System.out.println("Lorry " + Integer.toString(id) + " to Shop " + Integer.toString(shopId) + " : delivered : " + Integer.toString(record.getNum1()) + Character.toString(record.getMark()) + Integer.toString(record.getNum2()) + " = " + Integer.toString(record.getFinalResult()));

        isDelivered(true);

        System.out.println("Lorry " + Integer.toString(id) + " back to base");
    }

    public void checkManufacture(int type) {

        for (Object manufacture : manList) {
            if (manufacture instanceof ManufacturePattern) {
                man = (ManufacturePattern) manufacture;
                if (type == 1) {
                    if (man.getAddingQueueSize() >= 1) {
                        manId = man.getId();
                        break;
                    }
                }
                if (type == 2) {
                    if (man.getSubtractionQueueSize() >= 1) {
                        manId = man.getId();
                        break;
                    }
                }
                if (type == 3) {
                    if (man.getMultiplyingQueueSize() >= 1) {
                        manId = man.getId();
                        break;
                    }
                }
            }
        }
    }

    public void checkShop() {
        for (Object shop : shopList) {
            if (shop instanceof ShopPattern) {
                sh = (ShopPattern) shop;
                if (sh.getId() == shopId) {
                    break;
                }
            }
        }
    }

    public void isDelivered(boolean delivery) {
        free = delivery;
    }

    public boolean returnFreedom() {
        return free;
    }

}
