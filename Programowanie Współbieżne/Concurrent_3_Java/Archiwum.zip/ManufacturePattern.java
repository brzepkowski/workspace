
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author Asia
 */
public class ManufacturePattern {
    
    private final BlockingQueue addTaskQueue;
    private final BlockingQueue minTaskQueue;
    private final BlockingQueue multiTaskQueue;
    static ExecutorService service;
    static Data data;
    int id;
    
    ManufacturePattern(BlockingQueue addTaskQueue, BlockingQueue minTaskQueue, BlockingQueue multiTaskQueue, int id){
        data=new Data();
        this.addTaskQueue=addTaskQueue;
        this.minTaskQueue=minTaskQueue;
        this.multiTaskQueue=multiTaskQueue;
        this.id=id;
        
        
        
            int taskQueueL=data.taskQueue();
            int numMMachines=data.numberOfMultiplyingMachines();
            int numAMachines=data.numberOfAddingMachines();
            int numWorkers=data.numberOfProducers();

            BlockingQueue<Rekord> taskQueue = new LinkedBlockingQueue<>(taskQueueL);
            BlockingQueue<AddingMachine> addMachines = new ArrayBlockingQueue<>(numAMachines);
            BlockingQueue<MultiplyingMachine> multiplyingQueue = new ArrayBlockingQueue<>(numMMachines); //kolejka maszyn zajetych
            BlockingQueue<MultiplyingMachine> multiMachines = new ArrayBlockingQueue<>(numMMachines);
            BlockingQueue<Object> brokenMachines = new ArrayBlockingQueue<>(numMMachines+numAMachines);

            service=Executors.newFixedThreadPool(1);
            service.submit(new Boss(taskQueue, id));
            if(data.isUser()==false)
                System.out.println("Manufacture " + Integer.toString(id) +" boss at work");


            if(numMMachines>0){
                service=Executors.newFixedThreadPool(numMMachines);
                for(int k=0; k < numMMachines; k++){
                    MultiplyingMachine multi=new MultiplyingMachine(multiplyingQueue,k, id);
                    multiMachines.add(multi);
                    service.submit(multi);

                    if(data.isUser()==false)
                        System.out.println("Manufacture " + Integer.toString(id) +" Multiplying Machine " + Integer.toString(k) + " at work");
                }
            }

            if(numAMachines>0){
                //service=Executors.newFixedThreadPool(numAMachines);
                for(int k=0; k < numAMachines; k++){
                    AddingMachine addM= new AddingMachine(k, id);
                    addMachines.add(addM);
                  //  service.submit(addM);

                    if(data.isUser()==false)
                        System.out.println("Manufacture " + Integer.toString(id) +" Adding Machine " + Integer.toString(k) + " at work");
                }
            }

            service = Executors.newFixedThreadPool(numWorkers);
            service.submit(new Service(brokenMachines, addMachines, multiMachines, id));
            
            service = Executors.newFixedThreadPool(numWorkers);
            for (int i=0; i < numWorkers; i++) {
                service.submit(new Producer(taskQueue, addTaskQueue, minTaskQueue, multiTaskQueue, multiplyingQueue, brokenMachines, addMachines, multiMachines, i, id));

                if(data.isUser()==false)
                    System.out.println("Manufacture " + Integer.toString(id) +" Worker " + Integer.toString(i) + " at work");
            }
    }

    public int getId(){
        return id;
    }
    
    public int getAddingQueueSize(){
        return addTaskQueue.size();
    }
    
    public int getSubtractionQueueSize(){
        return minTaskQueue.size();
    }
    
    public int getMultiplyingQueueSize(){
        return multiTaskQueue.size();
    }
    
    public BlockingQueue addQReturn(){
        return addTaskQueue;
    }
    
    public BlockingQueue minQReturn(){
        return minTaskQueue;
    }
    
    public BlockingQueue multiQReturn(){
        return multiTaskQueue;
    }
    
}
