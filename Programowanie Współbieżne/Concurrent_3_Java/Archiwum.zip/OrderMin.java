
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Asia
 */
public class OrderMin implements Runnable{
    
    Data data; 
    LorryInc lorry;
    private final BlockingQueue minTask;
    private final BlockingQueue lorriesAv;
    int shopId;
    
    public OrderMin(BlockingQueue minTask, BlockingQueue lorriesAv, int shopId) {
        data=new Data();
        this.minTask=minTask;
        this.lorriesAv=lorriesAv;
        this.shopId=shopId;
    }

   @Override
    public void run() {
        
        while(true){ 
            if(minTask.size()<=1){
                callLorry("subtraction", 2);
            }
        }
    }
    
    public void callLorry(String action, int num){
        
        try {
            while(lorriesAv.isEmpty()){
                int takeSleepfe=data.makeSleepTime();
                    Thread.sleep(takeSleepfe);
            }
            
            lorry = (LorryInc) lorriesAv.take();
            System.out.println("Shop "+ Integer.toString(shopId)+ " : is ordering " + action);
            lorry.getType(num, shopId);
            
            while(lorry.returnFreedom()==false){
                    int takeSleepfe=data.makeSleepTime();
                    Thread.sleep(takeSleepfe);
                }
            lorriesAv.put(lorry);
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    
}
