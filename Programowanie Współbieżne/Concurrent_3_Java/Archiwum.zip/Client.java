import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client implements Runnable{
    
    
    private final BlockingQueue addTask, minTask, multiTask;
    Data data;
    Random rand;
    Rekord record=null;
    int id, shopId;
    
    public Client (BlockingQueue addTask, BlockingQueue minTask, BlockingQueue multiTask , int id, int shopId) {
        this.addTask=addTask;
        this.minTask=minTask;
        this.multiTask=multiTask;
        data=new Data();
        rand=new Random();
        this.id=id;
        this.shopId=shopId;
    }

    @Override
    public void run() {
        
        while(true){
            takeRecord();
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    } 

    public int returnID(){
        return id;
    }
    
    public void takeRecord(){       
        int min=0;
        int max=2;
        int number=rand.nextInt(max-min+1);
        int takeSleep=0;
            try {
                if(number==0){
                    synchronized (addTask) {
                        if (!addTask.isEmpty()) {
                            record = (Rekord) addTask.take();
                            System.out.println("Consumer " + Integer.toString(shopId) + "." + Integer.toString(id) + " : adding taken : " + Integer.toString(record.getNum1()) + Character.toString(record.getMark()) + Integer.toString(record.getNum2()) + " = " + Integer.toString(record.getFinalResult()));
                        }
                    }
                }
                else if(number==1){
                    synchronized (minTask) {
                        if (!minTask.isEmpty()) {
                            record = (Rekord) minTask.take();
                            System.out.println("Consumer " + Integer.toString(shopId) + "." + Integer.toString(id) + " : subtraction taken : " + Integer.toString(record.getNum1()) + Character.toString(record.getMark()) + Integer.toString(record.getNum2()) + " = " + Integer.toString(record.getFinalResult()));
                        }
                    }
                }
                else if(number==2){
                    synchronized (multiTask) {
                        if (!multiTask.isEmpty()) {
                            record = (Rekord) multiTask.take();
                            System.out.println("Consumer " + Integer.toString(shopId) + "." + Integer.toString(id) + " : multiplying taken : " + Integer.toString(record.getNum1()) + Character.toString(record.getMark()) + Integer.toString(record.getNum2()) + " = " + Integer.toString(record.getFinalResult()));
                        }
                    }
                }
                else{

                    System.out.println("NIE POWINIENEM TUTAJ BY�");
                    System.exit(1);

                   // if(data.isUser()==false)
                  //      System.out.println("YOLO");
                }
                
                if(record==null){
                    //if(data.isUser()==false)
                        //System.out.println("record was empty");
                }
            
            } catch (InterruptedException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);}  
        } 
    
}