
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Asia
 */
public class Service implements Runnable{
    
    Data data;
    private final BlockingQueue broken;
    private final BlockingQueue addMachines;
    private final BlockingQueue multiMachines;
    AddingMachine add;
    MultiplyingMachine multi;
    int manId;
    
    public Service(BlockingQueue brokenMachines, BlockingQueue addMachines, BlockingQueue multiMachines, int manId) {
        data=new Data();
        this.broken=brokenMachines;
        this.addMachines=addMachines;
        this.multiMachines=multiMachines;
        this.manId=manId;
    }

    @Override
    public void run() {
        while(true){
            if(!broken.isEmpty()){
                try {
                    
                    Object ob=broken.take();

                    int workHard=data.makeSleepTime();
                    Thread.sleep(workHard);

                    if(ob instanceof AddingMachine){
                        add=(AddingMachine) ob;
                        addMachines.put(add);
                        if(data.isUser()==false)
                            System.out.println("Service" + Integer.toString(manId) +" : Adding back " + Integer.toString(manId)+ "." + Integer.toString(add.returnID()));
                        
                    }

                    else if(ob instanceof MultiplyingMachine){
                        multi=(MultiplyingMachine) ob;
                        multiMachines.put(multi);
                        if(data.isUser()==false)
                            System.out.println("Service" + Integer.toString(manId)+" : Multiplying back " + Integer.toString(manId) + "." + Integer.toString(multi.returnID()));
                    }
                    
                    else{
                        if(data.isUser()==false)
                            System.out.println("WTF?");
                    }

                    int takeSleep=data.makeSleepTime();
                    Thread.sleep(takeSleep);
                    
                } catch (InterruptedException ex) {
                    Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } else {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
    
}
