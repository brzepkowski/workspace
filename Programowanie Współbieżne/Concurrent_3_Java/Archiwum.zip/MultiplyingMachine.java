    
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Asia
 */
public class MultiplyingMachine implements Runnable{
    
    private final BlockingQueue working;
    Data data;
    Rekord giveResult;
    boolean ifBroken=false,second=false;
    Rekord rekord;
    int number, id, manId;
    
    public MultiplyingMachine (BlockingQueue working, int id, int manId){
        this.working=working;
        data=new Data();
        this.id=id;
        this.manId=manId;
    }

    @Override
    public void run() {
        
        while(true){
            
            int takeSleep=data.makeSleepTime();
            try {
                Thread.sleep(takeSleep);
            } catch (InterruptedException ex) {
                Logger.getLogger(MultiplyingMachine.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    } 
    
    public int isBroken(){
        Random rand;
        rand=new Random();
        int min=0, max=20;
        number=rand.nextInt(max-min+1);
        return number;
    }
    
    public void PushSecondButton(boolean worker2){
        second=worker2;
    }
    
    public boolean returnSecond(){
        return second;
    }
            
    
    public Rekord giveRecord(Rekord cos){
        rekord=cos;
        return rekord;
    }
    
    public Rekord passTask() throws InterruptedException{
        Rekord newRekord= getData(rekord);
        
        return newRekord;
    }
    
    public Rekord getData(Rekord record) throws InterruptedException{
        int result=record.getFinalResult();
        char check='!';
        int num1 = 0,num2 =0;
            
            check=record.getMark();
            num1=record.getNum1();
            num2=record.getNum2();
            result=record.getFinalResult();

            result=num1*num2;
        
        if(data.isUser()==false)
            System.out.println("MM " + Integer.toString(manId) + "." + Integer.toString(id)+ " : Task "+ Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result + " solved");
        
        
        giveResult=new Rekord(num1, num2, check, result);
        return giveResult;
    }
    
    public boolean breakTime(boolean nieMamPomyslu){
        ifBroken=nieMamPomyslu;
        return ifBroken;
    }
    
    public boolean returnIsBroken(){
        return ifBroken;
    }
    
    public int returnID(){
        return id;
    }
}
