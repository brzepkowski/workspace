
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Asia
 */
public class Order implements Runnable{
    
    Data data; 
    LorryInc lorry;
    private final BlockingQueue addTask;
    private final BlockingQueue lorriesAv;
    int shopId;
    private int needed[]=new int[3];
    
    public Order(BlockingQueue addTask, BlockingQueue lorriesAv, int shopId) {
        data=new Data();
        this.addTask=addTask;
        this.lorriesAv=lorriesAv;
        this.shopId=shopId;
    }

   @Override
    public void run() {
        
        while(true){  
            if(addTask.size()<=1){
                callLorry("addition", 1);
            }
        }
    }
    
    public void callLorry(String action, int num){
        
        try {
            while(lorriesAv.isEmpty()){
                int takeSleepfe=data.makeSleepTime();
                Thread.sleep(takeSleepfe);
            }
            
            lorry = (LorryInc) lorriesAv.take();
            System.out.println("Shop "+ Integer.toString(shopId)+ " : is ordering " + action);
            lorry.getType(num, shopId);
            
            while(lorry.returnFreedom()==false){
                int takeSleepfe=data.makeSleepTime();
                Thread.sleep(takeSleepfe);
            }
            lorriesAv.put(lorry);
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Service.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
    
}
