
import java.util.Random;
/**
 *
 * @author Asia
 */
public class Data {
    
    public int makeSleepTime(){
        Random rand =new Random();
        int sleeptime = rand.nextInt(100);
        return sleeptime;
    }
    
    public int sleepLorry(){
        return 1;
    }
    
    public boolean isUser(){
        return false;
    }
    
    public int numberOfManufactures(){
        return 1;
    }
    
    public int numberOfShops(){
        return 2;
    }
    
    public int numberOfProducers(){
        return 3;
    }
    
    public int numberOfAddingMachines(){
        return 1;
    }
    
    public int numberOfMultiplyingMachines(){
        return 1;
    }
    
    public int numberOfClients(){
        return 4;
    }
    
    public int numberOfLorries(){
        return 5;
    }
    
    public int brokenProb(){
        return 1;
    }
    
    public int brokenMin(){
        return 0;
    }
    
    public int brokenMax(){
        return 20;
    }
    
    public int taskQueue(){
        return 2;
    }
    
    public int addQueue(){
        return 1;
    }
    
    public int minQueue(){
        return 2;
    }
    
    public int multiQueue(){
        return 2;
    }
    
}
