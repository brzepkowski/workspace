
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AddingMachine {
 
    Data data;
    Service service;
    Rekord giveResult;
    boolean ifBroken=false;
    int id, manId, number, result=Integer.MAX_VALUE;
    Random rand;
    
    public AddingMachine (int id,int manId){
        data=new Data();
        this.id=id;
        this.manId=manId;
    }
    
    public int isBroken(){
        int min=data.brokenMin();
        int max=data.brokenMax();
        number=rand.nextInt(max-min+1);
        return number;
    }

    public Rekord getData(Rekord record){
        
       
        char check=record.getMark();
        int num1=record.getNum1();
        int num2=record.getNum2();
        result=record.getFinalResult();
        
        result=num1+num2;
        
        if(data.isUser()==false)
            System.out.println("AM " + Integer.toString(manId) + "." + Integer.toString(id)+ " : Task " + Integer.toString(num1) + Character.toString(check) + Integer.toString(num2) + " = " + result + " solved");
        
        giveResult=new Rekord(num1, num2, check, result);
        
        return giveResult;
    }
    
    public int returnResult(){
        return result;
    }
    
    public boolean returnIsBroken(){
        return ifBroken;
    }
    
    public int returnID(){
        return id;
    }
}
