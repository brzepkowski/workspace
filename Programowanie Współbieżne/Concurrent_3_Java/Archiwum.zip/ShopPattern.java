import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author Asia
 */
public class ShopPattern {
    private final BlockingQueue addTaskMagazine;
    private final BlockingQueue minTaskMagazine;
    private final BlockingQueue multiTaskMagazine;
    private final BlockingQueue lorriesAv;
    
    static ExecutorService service;
    static Data data;
    static int id;
    
    public ShopPattern(BlockingQueue addTaskMagazine, BlockingQueue minTaskMagazine, BlockingQueue multiTaskMagazine, BlockingQueue lorriesAv, int id){
        this.addTaskMagazine=addTaskMagazine;
        this.minTaskMagazine=minTaskMagazine;
        this.multiTaskMagazine=multiTaskMagazine;
        this.lorriesAv=lorriesAv;
        data=new Data();
        this.id=id;
        
        int numClients = data.numberOfClients();

        service = Executors.newFixedThreadPool(1);
        service.submit( new Order(addTaskMagazine, lorriesAv, id));
        if(data.isUser()==false)
            System.out.println("Shop " + Integer.toString(id)+" Addition Orderman at work");

        service = Executors.newFixedThreadPool(1);
        service.submit( new OrderMin(minTaskMagazine, lorriesAv, id));
        if(data.isUser()==false)
            System.out.println("Shop " + Integer.toString(id)+" Subtraction Orderman at work");

        service = Executors.newFixedThreadPool(1);
        service.submit( new OrderMulti(multiTaskMagazine, lorriesAv, id));
        if(data.isUser()==false)
            System.out.println("Shop " + Integer.toString(id)+" Multiplying Orderman at work");

        
        service = Executors.newFixedThreadPool(numClients);
        for (int j=0; j < numClients; j++) {
            service.submit(new Client(addTaskMagazine, minTaskMagazine, multiTaskMagazine, j, id));
            if(data.isUser()==false)
                System.out.println("Shop " + Integer.toString(id) + " Consumer " + Integer.toString(j) + " inside");
        }
        
    }


    public int getId(){
        return id;
    }
    
    public BlockingQueue addQReturn(){
        return addTaskMagazine;
    }
    
    public BlockingQueue minQReturn(){
        return minTaskMagazine;
    }
    
    public BlockingQueue multiQReturn(){
        return multiTaskMagazine;
    }
}
