
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Boss implements Runnable {
    Data data;
    Random rand;
    char retChar;
    int manId;

    private final BlockingQueue<Rekord> queueBP;

    public Boss(BlockingQueue<Rekord> queueBC, int manId) {
        this.queueBP = queueBC;
        data = new Data();
        rand = new Random();
        this.manId = manId;
    }

    public int takeNumber() {
        rand = new Random();
        int min = 1;
        int max = 9;
        int number = rand.nextInt(max - min + 1);

        return number;
    }

    public char takeChar() {
        char[] chooseChar = {'+', '-', '*'};

        int min = 0;
        int max = 2;
        int number = rand.nextInt(max - min + 1);

        if (number == 0) {
            retChar = chooseChar[0];
            if (data.numberOfAddingMachines() <= 0)
                takeChar();
        } else if (number == 1) {
            retChar = chooseChar[1];
        } else if (number == 2) {
            retChar = chooseChar[2];
            if (data.numberOfMultiplyingMachines() <= 0)
                takeChar();
        } else {
            retChar = '!';
        }

        return retChar;
    }


    @Override
    public void run() {
        while (true) {

            char retChar = takeChar();
            int a = takeNumber();
            int b = takeNumber();

            if (data.numberOfProducers() == 0) {
                if (data.isUser() == false)
                    System.out.println("No worker at work, it's kit-kat time");
                System.exit(0);
            }

            int taskQueueL = data.taskQueue();

            try {
                if (data.isUser() == false)

                    System.out.println("Boss " + Integer.toString(manId) + ".0 : Task: " + Integer.toString(a) + retChar + Integer.toString(b) + " created");

                while (queueBP.size() == data.taskQueue()) {
                    //if(data.isUser()==false)
                    //    System.out.println("Boss " + Integer.toString(manId) +".0 : Too many things on task list. Boss is waiting");
                    int takeWait = data.makeSleepTime();
                    Thread.sleep(takeWait);
                }

                if (data.numberOfAddingMachines() == 0 && retChar == '+') {
                    while (retChar == '+') {
                        retChar = takeChar();
                    }
                }
                if (data.numberOfMultiplyingMachines() == 0 && retChar == '*') {
                    while (retChar == '*') {
                        retChar = takeChar();
                    }
                }

                queueBP.put(new Rekord(a, b, retChar, Integer.MAX_VALUE));

                int takeSleep = data.makeSleepTime();
                Thread.sleep(takeSleep);
            } catch (InterruptedException ex) {
                Logger.getLogger(Boss.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
