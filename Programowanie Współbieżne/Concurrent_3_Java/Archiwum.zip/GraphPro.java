import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import org.jgrapht.alg.ConnectivityInspector;
import org.jgrapht.graph.*;
import org.jgrapht.graph.AbstractBaseGraph;
/**
 *
 * @author Asia
 */
public class GraphPro {
    
    public static ConnectivityInspector<Integer, DefaultWeightedEdge> connectivityInspector;
    public static SimpleWeightedGraph<Integer, DefaultWeightedEdge> G;
    public static DefaultWeightedEdge[][] E; 
    public static int[] V;
    private static String[] kind;
    
    static Random rand;
    static ExecutorService service;
    static Data data;
    private ManufacturePattern manufacture;
    private ShopPattern shop;
    private static int numberOfVertices;
    private static int numberOfEdges;
    private static int manNum;
    public static int shopNum;
    public static int lorriesNum;
    static int manCounter, b;
    
    
    public static void main(String [] args)
    {        
        data=new Data();
        manNum=data.numberOfManufactures();
        shopNum=data.numberOfShops();
        lorriesNum = data.numberOfLorries();
        
        int addQueueL = data.addQueue();
        int minQueueL = data.minQueue();
        int multiQueueL = data.multiQueue();
        
        if(manNum==0){
            System.out.println("W kulki lecisz, nic nie wyprodukuję");
            System.exit(0);
        }
        
        if(shopNum==0){
            System.out.println("Brak sklepów - sajonara");
            System.exit(0);
        }
        
        
        BlockingQueue<Rekord> addTaskQueue;
        BlockingQueue<Rekord> minTaskQueue;
        BlockingQueue<Rekord> multiTaskQueue;
        BlockingQueue<Rekord> addTaskMagazine;
        BlockingQueue<Rekord> minTaskMagazine;
        BlockingQueue<Rekord> multiTaskMagazine;
        BlockingQueue<LorryInc> lorriesAv = new LinkedBlockingQueue<LorryInc>(lorriesNum);
        CopyOnWriteArrayList<ManufacturePattern> manList = new CopyOnWriteArrayList<ManufacturePattern>();
        CopyOnWriteArrayList<ShopPattern> shopList = new CopyOnWriteArrayList<ShopPattern>();
        
        
        numberOfVertices = data.numberOfManufactures() + data.numberOfShops() + 1;
	//numberOfEdges = getNumberOfEdges(numberOfVertices-1,(numberOfVertices*(numberOfVertices-1))/2);
        numberOfEdges=numberOfVertices-1;
        
        kind=new String[numberOfVertices];
        
    	V = new int[numberOfVertices];
        G = createWeightedGraph();
        
      //  service=Executors.newFixedThreadPool(manNum);
        for(int k=0; k < manNum; k++){
            addTaskQueue = new LinkedBlockingQueue<Rekord>(data.addQueue());
            minTaskQueue = new LinkedBlockingQueue<Rekord>(data.minQueue());
            multiTaskQueue = new LinkedBlockingQueue<Rekord>(data.multiQueue());
            
            if(data.isUser()==false)
                System.out.println(Integer.toString(k) + " Manufacture starts");
            
            ManufacturePattern manPat=new ManufacturePattern(addTaskQueue, minTaskQueue, multiTaskQueue, k);
            manList.add(manPat);
          //  service.submit(manPat);
        }    
            
      //  service=Executors.newFixedThreadPool(shopNum);
        for(int k=0; k < shopNum; k++){
            addTaskMagazine = new LinkedBlockingQueue<Rekord>(addQueueL);
            minTaskMagazine = new LinkedBlockingQueue<Rekord>(minQueueL);
            multiTaskMagazine = new LinkedBlockingQueue<Rekord>(multiQueueL);
             
            if(data.isUser()==false)
                System.out.println(Integer.toString(k) + " Shop starts");
            
            ShopPattern shopPat=new ShopPattern(addTaskMagazine, minTaskMagazine, multiTaskMagazine, lorriesAv, k);
            shopList.add(shopPat);
           // service.submit(shopPat);
        }
            
           
      //  service=Executors.newFixedThreadPool(lorriesNum);
        for(int k=0; k < lorriesNum; k++){
            
            if(data.isUser()==false)
                System.out.println(Integer.toString(k) + " Lorry starts");
            
            LorryInc lorryC=new LorryInc(manList, shopList, k);
            lorriesAv.add(lorryC);
         //   service.submit(lorryC);
        }
        
        
        if(data.isUser()==true){ 
            System.out.println("welcome User \n");
            service=Executors.newFixedThreadPool(1);
            service.submit(new User(manList, shopList));
        }
        
        
        
    }
    
    private static DefaultWeightedEdge createEdge(int i, int j) {
    	DefaultWeightedEdge e = G.getEdge(i,j);
        System.out.println("***CreateEdge is " + e);
    	return e;
    }
    
    private static int createVertex(int i) {
    	int v = V[i-1];
    	return v;
    }
    
    private static void setSomeWeight(DefaultWeightedEdge e, double weight) {
    	G.setEdgeWeight(e, weight);
        System.out.println("*** Weight is " + weight);
    }
    
    
    private static SimpleWeightedGraph<Integer, DefaultWeightedEdge> createWeightedGraph() {
    	
    	G = new SimpleWeightedGraph<Integer, DefaultWeightedEdge>(DefaultWeightedEdge.class);

        manCounter=0;
        b=0;
        
    	for (int i = 0; i < numberOfVertices; i++) {
            V[i] = i+1;
            G.addVertex(createVertex(i+1));
                
            if(i==0){
                kind[i]="lorry";
                System.out.println("Vertex " + (i+1) + " is for " + kind[i]);
            }
            else{
                if(!(shopNum==0 && manNum==0)){
                    String chosenPattern=definePattern(manCounter,b);
                    kind[i]=chosenPattern;
                    System.out.println("* Vertex " + (i+1) + " is for " + kind[i]);
                }
            }
    	}
    
    	for (int i = 1; i <= numberOfEdges; i++) {
    		DefaultWeightedEdge edge = G.addEdge(1,i+1);
                System.out.println("***Edge is " + edge);
    	}
    	
    	for (int i = 1; i <= numberOfEdges; i++) {
            int weight = randomWeight();
    		setSomeWeight(createEdge(1, i+1), weight);
        }
        
        System.out.println("---");
        System.out.println(G);
        System.out.println("---");
        
    	return G;
    }
    
    /*
    private static SimpleWeightedGraph<Integer, DefaultWeightedEdge> createWeightedGraph() {
    	G = new SimpleWeightedGraph<Integer, DefaultWeightedEdge>(DefaultWeightedEdge.class);
        
        a=0;
        b=0;
        
    	for (int i = 0; i < numberOfVertices; i++) {
            V[i] = i+1;
            G.addVertex(createVertex(i+1));
            
            if(i==0){
                kind[i]="lorry";
            }
            else{
                if(!(data.numberOfShops()==0 && data.numberOfManufactures()==0)){
                    String chosenPattern=definePattern(a,b);
                    kind[i]=chosenPattern;}
                else if(data.numberOfManufactures()==0){
                    kind[i]="shop" + Integer.toString(a);}
                else if(data.numberOfShops()==0){
                    kind[i]="manufacture" + Integer.toString(b);}
            }
        }
        
        DefaultWeightedEdge consEdge[] = G.edgeSet().toArray(new DefaultWeightedEdge[0]);
        //dla randoma
        for ( int i=0; i<=G.edgeSet().size(); i++) {
            System.out.println("+++" + consEdge[i]);
            //setSomeWeight(, randomWeight());
        }
               
        
        
        ConnectivityInspector connectivityInspector = new ConnectivityInspector<Integer, DefaultWeightedEdge>(G);
            boolean isConnected = connectivityInspector.isGraphConnected();
    		if (isConnected == false) {
                    G = createWeightedGraph();}
        
    	return G;
    }
    
    
    private static DefaultWeightedEdge checkEdge(){
        int vertex1=getNumber(0, numberOfVertices);
        int vertex2=getNumber(0, numberOfVertices);
        DefaultWeightedEdge edge=null;
        if(vertex1!=vertex2){
            if(G.containsEdge(vertex1,vertex2)==false && G.containsEdge(vertex2,vertex1)==false){
                edge = G.addEdge(vertex1, vertex2); }
            else{
                checkEdge();}
        }
        else{
            checkEdge();}
                
        return edge;
    }
    
     public static int getNumberOfEdges(int min, int max){
        
        rand=new Random();
        int numberOfEdges=rand.nextInt(max-min+1);
        
        if(numberOfEdges<numberOfVertices)
            getNumberOfEdges(min, max);
        return numberOfEdges;
    }
    */
     
    private static String definePattern(int a2, int b2){
        
        String pattern="eciepecie";
        rand=new Random();
        int name=rand.nextInt(2);
        if(name==0) {
            if(manNum!=a2){
                pattern="manufacture" + Integer.toString(manCounter);
                manCounter++;
            }
            else{
                pattern= "shop" + Integer.toString(b);
                b++;
            }
        }
        else if(name==1){
            if(shopNum!=b2){
                pattern="shop" + Integer.toString(b);
                b++;
            }
            else{
                pattern= "manufacture" + Integer.toString(manCounter);
                manCounter++;
            }
        }
        
        return pattern;
    }
    
    private static int randomWeight(){
     
        rand=new Random();
        int weight=rand.nextInt(20);
        
        return weight;
    }
     
    public static int getNumber(int min, int max){
        
        rand=new Random();
        int numberOfEdges=rand.nextInt(max-min+1);
        
        return numberOfEdges;
    }
      
    public String kindArrayElem(int i){
        String wanted = kind[i];
        return wanted;
    }
    
    public int returnWeight(int i, int j){
        DefaultWeightedEdge foundEdge=G.getEdge(i,j);
        int weight=(int) G.getEdgeWeight(foundEdge);
        return weight;
    }
    

}
    

