
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asia
 */
public class User implements Runnable{
    
    private final CopyOnWriteArrayList shopList, manList;
    private int showMenu=0;
    String showTime="";
    Data data;
    
    public User (CopyOnWriteArrayList manList, CopyOnWriteArrayList shopList) {
        this.manList = manList;
        this.shopList = shopList;
        data=new Data(); 
    }

    @Override
    public void run() {
        
        while(true){
            if(data.isUser()==true){

                whenMenu();

                scannerIsComing();

                System.out.println(String.format("%s", showTime));

                switch(showTime){
                    case "b":{
                        System.out.println("There is a place. Like no place on Earth. A land full of wonder, mystery, and danger! Some say to survive it: You need to be as mad as a hatter.");
                        System.out.println(manList);
                        showMenu=0;
                        whenMenu();
                        break;
                    }
                    case "r":{
                        System.out.println("You're entirely bonkers. But I'll tell you a secret. All the best people are.");
                        System.out.println(shopList);
                        showMenu=0;
                        whenMenu();
                        break;
                    }
                    default:{
                        System.out.println("Is our situation not dismal? Wonderland is so discombobulated that lady bugs have turned belligerent and enlisted in the queen's army!");
                        showMenu=0;
                        whenMenu();
                        break;
                    }
                }
            }
        }    
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void printfowanie(){
        System.out.println("\nThis is your last chance. After this, there is no turning back. You take the blue pill - the story ends, you wake up in your bed and believe whatever you want to believe. You take the red pill - you stay in Wonderland and I show you how deep the rabbit-hole goes.");
        System.out.println("b -blue: manufacture list state");
        System.out.println("r -red: shop list state");
    }
    
    public void whenMenu(){
        if(showMenu==0){
            printfowanie();
            showMenu=1;
        }
    }
    
    public void scannerIsComing(){
            Scanner scanner = new Scanner(System.in);      
            showTime = scanner.next();
            System.out.println(String.format("You choose %s", showTime));
    }
    
}
