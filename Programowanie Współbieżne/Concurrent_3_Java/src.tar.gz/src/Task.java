
public class Task {
	public int argument_1;
	public char operator;
	public int argument_2;
	public int product;
	
	Task() {
		argument_1 = '-';
		operator = '-';
		argument_2 = '-';
		product = '-';
	}
}